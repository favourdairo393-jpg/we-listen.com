
export interface User {
  id: string;
  email: string;
  anonymousName: string;
  preferredLanguage: string;
  lastPostDate?: string; // YYYY-MM-DD
  streak: number;
}

export interface Reply {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  timestamp: number;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  questionId: string;
  timestamp: number;
  replies: Reply[];
  language?: string;
}

export interface DailyQuestion {
  id: string;
  text: string;
  date: string; // YYYY-MM-DD
}
