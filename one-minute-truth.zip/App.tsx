
import React, { useState, useEffect, useCallback } from 'react';
import { User, Post, DailyQuestion, Reply } from './types';
import { generateAnonymousName, getTodayDateString, canUserPostToday } from './utils/helpers';
import { getDailyQuestion } from './services/geminiService';
import Auth from './components/Auth';
import Header from './components/Header';
import DailyPrompt from './components/DailyPrompt';
import PostFeed from './components/PostFeed';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [dailyQuestion, setDailyQuestion] = useState<DailyQuestion | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize App
  useEffect(() => {
    const init = async () => {
      // 1. Check local storage for session
      const storedUser = localStorage.getItem('omt_user');
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        // Ensure anonymous name is up to date with the week
        parsedUser.anonymousName = generateAnonymousName(parsedUser.email);
        setUser(parsedUser);
      }

      // 2. Load/Fetch Daily Question
      const questionText = await getDailyQuestion();
      setDailyQuestion({
        id: 'q-' + getTodayDateString(),
        text: questionText,
        date: getTodayDateString(),
      });

      // 3. Load Posts from LocalStorage (Mock Database)
      const storedPosts = localStorage.getItem('omt_posts');
      if (storedPosts) {
        setPosts(JSON.parse(storedPosts));
      } else {
        // Initial Mock Data
        const mockPosts: Post[] = [
          {
            id: '1',
            authorId: 'mock-1',
            authorName: 'User 4821',
            content: "I pretend to be confident because I'm terrified that if people see my doubt, they'll realize I have no idea what I'm doing. It's exhausting carrying a mask every single day.",
            questionId: 'q-' + getTodayDateString(),
            timestamp: Date.now() - 3600000,
            replies: [],
          },
          {
            id: '2',
            authorId: 'mock-2',
            authorName: 'User 1029',
            content: "I'm pretending to be happy in my marriage. My partner is great, but the spark died years ago and I'm just staying for the comfort. I feel like a ghost in my own home.",
            questionId: 'q-' + getTodayDateString(),
            timestamp: Date.now() - 7200000,
            replies: [
              {
                id: 'r1',
                authorId: 'mock-3',
                authorName: 'User 8821',
                content: "I feel this so deeply. Sometimes the comfort is the cage.",
                timestamp: Date.now() - 3600000,
              }
            ],
          }
        ];
        setPosts(mockPosts);
        localStorage.setItem('omt_posts', JSON.stringify(mockPosts));
      }

      setIsLoading(false);
    };

    init();
  }, []);

  const handleLogin = (email: string) => {
    const newUser: User = {
      id: btoa(email),
      email,
      anonymousName: generateAnonymousName(email),
      preferredLanguage: 'English',
      streak: 0,
    };
    setUser(newUser);
    localStorage.setItem('omt_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('omt_user');
  };

  const handlePostSubmit = (content: string) => {
    if (!user || !dailyQuestion) return;

    const newPost: Post = {
      id: Date.now().toString(),
      authorId: user.id,
      authorName: user.anonymousName,
      content,
      questionId: dailyQuestion.id,
      timestamp: Date.now(),
      replies: [],
    };

    const updatedPosts = [newPost, ...posts];
    setPosts(updatedPosts);
    localStorage.setItem('omt_posts', JSON.stringify(updatedPosts));

    const updatedUser = { ...user, lastPostDate: getTodayDateString(), streak: user.streak + 1 };
    setUser(updatedUser);
    localStorage.setItem('omt_user', JSON.stringify(updatedUser));
  };

  const handleReplySubmit = (postId: string, replyContent: string) => {
    if (!user) return;

    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          replies: [
            ...post.replies,
            {
              id: Date.now().toString(),
              authorId: user.id,
              authorName: user.anonymousName,
              content: replyContent,
              timestamp: Date.now(),
            }
          ]
        };
      }
      return post;
    });

    setPosts(updatedPosts);
    localStorage.setItem('omt_posts', JSON.stringify(updatedPosts));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
        <div className="animate-pulse text-white/50 text-sm tracking-widest uppercase">One Minute Truth...</div>
      </div>
    );
  }

  if (!user) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen max-w-2xl mx-auto px-4 py-8 flex flex-col gap-12">
      <Header user={user} onLogout={handleLogout} />
      
      <main className="flex-1 space-y-12">
        <DailyPrompt 
          question={dailyQuestion?.text || ""} 
          hasPosted={!canUserPostToday(user.lastPostDate)}
          onSubmit={handlePostSubmit}
        />
        
        <div className="border-t border-white/5 pt-12">
          <h2 className="text-xs font-semibold tracking-widest text-white/30 uppercase mb-8">Voices from Today</h2>
          <PostFeed 
            posts={posts} 
            user={user}
            onReply={handleReplySubmit}
            preferredLanguage={user.preferredLanguage}
          />
        </div>
      </main>

      <footer className="py-8 text-center text-white/20 text-xs">
        &copy; {new Date().getFullYear()} One Minute Truth. We listen. We don't judge.
      </footer>
    </div>
  );
};

export default App;
