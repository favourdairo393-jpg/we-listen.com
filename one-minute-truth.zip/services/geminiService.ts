
import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.API_KEY || "";
const ai = new GoogleGenAI({ apiKey });

export const translateText = async (text: string, targetLanguage: string): Promise<string> => {
  if (!apiKey) return "Translation unavailable: API Key missing.";
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Translate the following anonymous confession into ${targetLanguage}. Maintain the tone and emotional weight. Provide ONLY the translated text.\n\nText: "${text}"`,
    });
    return response.text || "Could not translate text.";
  } catch (error) {
    console.error("Translation error:", error);
    return "An error occurred during translation.";
  }
};

export const getDailyQuestion = async (): Promise<string> => {
  // In a real app, this would be fetched from a DB or specific seed.
  // For the demo, we generate a profound one if we don't have one cached.
  const questions = [
    "Who are you pretending to be—and why?",
    "What is a truth about yourself that you've never spoken out loud?",
    "If you could apologize to one person from your past without them knowing it was you, what would you say?",
    "What is the heaviest thing you are carrying right now?",
    "What part of your personality do you hide because you think it's unlovable?",
    "What lie do you tell yourself most often to get through the day?",
    "What do you miss most about the person you used to be?",
  ];
  
  const index = Math.floor(Date.now() / (24 * 60 * 60 * 1000)) % questions.length;
  return questions[index];
};
