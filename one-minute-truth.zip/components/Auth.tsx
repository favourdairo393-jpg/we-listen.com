
import React, { useState } from 'react';

interface AuthProps {
  onLogin: (email: string) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      onLogin(email);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#0a0a0a]">
      <div className="w-full max-w-sm space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-4xl serif-text font-bold tracking-tighter">One Minute Truth</h1>
          <p className="text-white/40 text-sm leading-relaxed font-light">
            An experiment in radical honesty.<br/>
            One question. One answer. Total anonymity.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] uppercase tracking-widest font-bold text-white/30 ml-1">Email</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="w-full bg-white/5 border border-white/5 focus:border-white/20 rounded-2xl px-6 py-4 text-white focus:outline-none transition-all"
                required
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] uppercase tracking-widest font-bold text-white/30 ml-1">Password</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-white/5 border border-white/5 focus:border-white/20 rounded-2xl px-6 py-4 text-white focus:outline-none transition-all"
                required
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-white text-black font-bold py-4 rounded-full hover:bg-white/90 transition-all uppercase tracking-widest text-xs"
          >
            Enter Sanctuary
          </button>
          
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/5"></div>
            </div>
            <div className="relative flex justify-center text-[10px] uppercase tracking-widest font-bold">
              <span className="bg-[#0a0a0a] px-4 text-white/20">or</span>
            </div>
          </div>

          <button 
            type="button"
            onClick={() => onLogin('google-user@gmail.com')}
            className="w-full bg-white/5 text-white/80 border border-white/10 font-bold py-4 rounded-full hover:bg-white/10 transition-all uppercase tracking-widest text-xs flex items-center justify-center gap-3"
          >
            <i className="fa-brands fa-google"></i>
            Continue with Google
          </button>
        </form>

        <p className="text-center text-[10px] text-white/20 uppercase tracking-widest leading-loose">
          By entering, you agree to be kind.<br/>
          Your identity is protected by the machine.
        </p>
      </div>
    </div>
  );
};

export default Auth;
