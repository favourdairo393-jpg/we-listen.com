
import React, { useState } from 'react';
import { Post, User } from '../types';
import { formatTimestamp } from '../utils/helpers';
import { translateText } from '../services/geminiService';

interface PostItemProps {
  post: Post;
  currentUser: User;
  onReply: (postId: string, content: string) => void;
  preferredLanguage: string;
}

const PostItem: React.FC<PostItemProps> = ({ post, currentUser, onReply, preferredLanguage }) => {
  const [isReplying, setIsReplying] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);

  const handleTranslate = async () => {
    if (translatedText) {
      setTranslatedText(null);
      return;
    }
    
    setIsTranslating(true);
    const result = await translateText(post.content, preferredLanguage);
    setTranslatedText(result);
    setIsTranslating(false);
  };

  const handleReply = () => {
    if (!replyText.trim()) return;
    onReply(post.id, replyText);
    setReplyText('');
    setIsReplying(false);
  };

  return (
    <div className="glass-card rounded-2xl p-6 transition-all hover:border-white/10 group">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">{post.authorName}</span>
          <span className="text-white/10">•</span>
          <span className="text-[10px] text-white/20 uppercase tracking-widest">{formatTimestamp(post.timestamp)}</span>
        </div>
        
        <button 
          onClick={handleTranslate}
          disabled={isTranslating}
          className="text-[10px] font-bold text-white/20 hover:text-white/60 transition-colors uppercase tracking-widest"
        >
          {isTranslating ? '...' : translatedText ? 'Show Original' : 'Translate'}
        </button>
      </div>

      <p className="text-white/80 leading-relaxed text-base">
        {translatedText || post.content}
      </p>

      <div className="mt-6 flex flex-col gap-4">
        {/* Actions */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsReplying(!isReplying)}
            className="text-[10px] font-bold text-white/30 hover:text-white/80 transition-colors uppercase tracking-widest flex items-center gap-2"
          >
            <i className="fa-regular fa-comment"></i>
            {post.replies.length > 0 ? `${post.replies.length} Reply` : 'Reply'}
          </button>
        </div>

        {/* Reply Input */}
        {isReplying && (
          <div className="pt-2 animate-in fade-in slide-in-from-top-2 duration-300">
            <textarea
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="Add your anonymous reply..."
              className="w-full bg-white/5 border border-white/5 rounded-xl p-4 text-sm focus:outline-none focus:ring-1 focus:ring-white/20 resize-none h-24 transition-all"
            />
            <div className="flex justify-end gap-2 mt-2">
              <button 
                onClick={() => setIsReplying(false)}
                className="px-4 py-2 text-[10px] uppercase font-bold text-white/30 hover:text-white/60"
              >
                Cancel
              </button>
              <button 
                onClick={handleReply}
                disabled={!replyText.trim()}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-[10px] uppercase font-bold rounded-full disabled:opacity-30 transition-all"
              >
                Post Reply
              </button>
            </div>
          </div>
        )}

        {/* Replies List (Single Layer) */}
        {post.replies.length > 0 && (
          <div className="space-y-3 mt-2 pl-4 border-l border-white/5">
            {post.replies.map((reply) => (
              <div key={reply.id} className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-bold text-white/30 uppercase tracking-widest">{reply.authorName}</span>
                  <span className="text-[9px] text-white/10 uppercase tracking-widest">{formatTimestamp(reply.timestamp)}</span>
                </div>
                <p className="text-white/60 text-sm leading-snug">
                  {reply.content}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PostItem;
