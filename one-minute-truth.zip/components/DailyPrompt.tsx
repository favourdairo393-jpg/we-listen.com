
import React, { useState } from 'react';

interface DailyPromptProps {
  question: string;
  hasPosted: boolean;
  onSubmit: (content: string) => void;
}

const DailyPrompt: React.FC<DailyPromptProps> = ({ question, hasPosted, onSubmit }) => {
  const [content, setContent] = useState('');

  const handleSubmit = () => {
    if (!content.trim()) return;
    onSubmit(content);
    setContent('');
  };

  if (hasPosted) {
    return (
      <div className="glass-card p-10 rounded-3xl text-center space-y-4">
        <div className="w-12 h-12 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="fa-solid fa-check"></i>
        </div>
        <h3 className="text-xl font-medium serif-text italic text-white/90">Truth shared.</h3>
        <p className="text-white/40 text-sm max-w-xs mx-auto">
          You've contributed to today's truth. See what others are feeling below. Come back tomorrow for a new question.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="space-y-3">
        <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/30">Today's Hook</span>
        <h1 className="text-3xl md:text-4xl lg:text-5xl serif-text leading-tight text-white/90">
          {question}
        </h1>
      </div>

      <div className="relative">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Type your truth here... No one will know it was you."
          className="w-full h-48 bg-white/5 rounded-2xl p-6 text-lg focus:outline-none focus:ring-1 focus:ring-white/20 transition-all resize-none border border-transparent placeholder:text-white/10"
        />
        <div className="flex justify-end mt-4">
          <button
            onClick={handleSubmit}
            disabled={!content.trim()}
            className="px-8 py-3 bg-white text-black font-bold rounded-full hover:bg-white/90 disabled:opacity-30 disabled:cursor-not-allowed transition-all uppercase tracking-widest text-xs"
          >
            Submit Truth
          </button>
        </div>
      </div>
    </div>
  );
};

export default DailyPrompt;
