
import React from 'react';
import { User } from '../types';

interface HeaderProps {
  user: User;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
  return (
    <header className="flex items-center justify-between py-4">
      <div className="flex flex-col">
        <span className="text-xl font-bold tracking-tighter serif-text">One Minute Truth</span>
        <div className="flex items-center gap-2 mt-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-[10px] text-white/40 uppercase tracking-widest font-semibold">{user.anonymousName}</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {user.streak > 0 && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-500/10 text-orange-400 text-xs font-bold border border-orange-500/20">
            <i className="fa-solid fa-fire"></i>
            {user.streak}
          </div>
        )}
        <button 
          onClick={onLogout}
          className="text-white/30 hover:text-white transition-colors text-xs uppercase tracking-widest font-semibold"
        >
          Exit
        </button>
      </div>
    </header>
  );
};

export default Header;
