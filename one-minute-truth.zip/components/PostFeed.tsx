
import React from 'react';
import { Post, User } from '../types';
import PostItem from './PostItem';

interface PostFeedProps {
  posts: Post[];
  user: User;
  onReply: (postId: string, content: string) => void;
  preferredLanguage: string;
}

const PostFeed: React.FC<PostFeedProps> = ({ posts, user, onReply, preferredLanguage }) => {
  if (posts.length === 0) {
    return (
      <div className="text-center py-20 opacity-30 italic serif-text">
        The silence is loud. Be the first to break it.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {posts.map((post) => (
        <PostItem 
          key={post.id} 
          post={post} 
          currentUser={user}
          onReply={onReply}
          preferredLanguage={preferredLanguage}
        />
      ))}
    </div>
  );
};

export default PostFeed;
