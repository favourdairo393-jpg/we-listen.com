
export const generateAnonymousName = (email: string): string => {
  // Generate a weekly-rotating anonymous name
  const weekNumber = Math.floor(Date.now() / (7 * 24 * 60 * 60 * 1000));
  const hashSource = `${email}-${weekNumber}`;
  let hash = 0;
  for (let i = 0; i < hashSource.length; i++) {
    const char = hashSource.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  const id = Math.abs(hash % 10000).toString().padStart(4, '0');
  return `User ${id}`;
};

export const getTodayDateString = (): string => {
  return new Date().toISOString().split('T')[0];
};

export const canUserPostToday = (lastPostDate?: string): boolean => {
  if (!lastPostDate) return true;
  return lastPostDate !== getTodayDateString();
};

export const formatTimestamp = (timestamp: number): string => {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return 'Just now';
};
